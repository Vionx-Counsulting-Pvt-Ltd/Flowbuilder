---
name: Vite optimized dependency cache
description: Diagnose stale optimized peer versions in Vite workspace artifacts.
---

When Vite reports incompatible React versions even though the app resolves matching `react` and `react-dom` packages, inspect its optimized dependency metadata first. Restarting the managed workflow may reuse stale optimization data; clear only that artifact's generated `.vite/deps` cache and restart before changing dependency versions.

**Why:** the FlowBuilder preview retained an old React 19.1.0 optimizer entry after its installed packages were aligned to 19.1.4, and workflow restart alone did not replace it.

**How to apply:** Compare resolved package versions with `node_modules/.vite/deps/_metadata.json`. If the metadata is stale, remove that artifact's `node_modules/.vite/deps` directory and restart its existing managed web workflow. Avoid changing a workspace-wide React catalog when another app depends on its pinned version.
